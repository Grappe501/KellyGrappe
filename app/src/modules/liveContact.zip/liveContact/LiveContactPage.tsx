// app/src/modules/liveContact/LiveContactPage.tsx

import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";

import Container from "../../shared/components/Container";
import { Card, CardHeader, CardContent } from "../../shared/components/Card";
import { Button } from "../../shared/components/FormControls";

import type { LiveContactForm } from "./types/LiveContactForm";

import { ContactIdentitySection } from "./components/ContactIdentitySection";
import { ContactLocationSection } from "./components/ContactLocationSection";
import { MeetingContextSection } from "./components/MeetingContextSection";
import { SocialProfilesSection } from "./components/SocialProfilesSection";
import { CampaignCategorySection } from "./components/CampaignCategorySection";
import { TeamAssignmentSection } from "./components/TeamAssignmentSection";
import { EngagementSignalsSection } from "./components/EngagementSignalsSection";
import { ConversationNotesSection } from "./components/ConversationNotesSection";
import { FollowUpSection } from "./components/FollowUpSection";
import { PhotoCaptureSection } from "./components/PhotoCaptureSection";

import { useLiveContactForm } from "./hooks/useLiveContactForm";
import { usePhotoCapture } from "./hooks/usePhotoCapture";
import { buildFollowupPayload } from "./services/followupPayloadBuilder";
import { syncPendingFollowUps } from "../../shared/utils/syncEngine";

import {
  addContactMedia,
  addLiveFollowUp,
  addOrigin,
  upsertContact,
} from "../../shared/utils/contactsDb";

/**
 * Production-grade Live Contact Entry
 * - Offline-first
 * - Canvassing-speed UX
 * - Canonical schema + origin logging
 * - LiveFollowUp always written locally (never disappears)
 */
export default function LiveContactPage() {
  const nav = useNavigate();

  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [justSaved, setJustSaved] = useState(false);

  // Form state (single canonical shape)
  const { form, update, reset } = useLiveContactForm();

  // Photo capture (offline stored + later sync)
  const { photo, setPhoto, clearPhoto } = usePhotoCapture();

  const readyToSave = useMemo(() => {
    // Keep it fast: require initials + at least a name or a phone/email
    const hasInitials = (form.entryInitials || "").trim().length >= 2;
    const hasIdentity =
      (form.fullName || "").trim().length > 0 ||
      (form.phone || "").trim().length > 0 ||
      (form.email || "").trim().length > 0;

    return hasInitials && hasIdentity;
  }, [form.entryInitials, form.fullName, form.phone, form.email]);

  // Clear the “saved” toast when user starts typing again
  useEffect(() => {
    if (justSaved) {
      const t = window.setTimeout(() => setJustSaved(false), 1500);
      return () => window.clearTimeout(t);
    }
  }, [justSaved]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!readyToSave || submitting) return;

    setSubmitting(true);
    setSubmitError(null);

    try {
      // 1) Upsert canonical Contact
      const contact = await upsertContact({
        fullName: form.fullName,
        phone: form.phone,
        email: form.email,
        city: form.city,
        county: form.county,
        state: form.state,
        zip: form.zip,

        precinct: form.precinct,
        congressionalDistrict: form.congressionalDistrict,
        stateHouseDistrict: form.stateHouseDistrict,
        stateSenateDistrict: form.stateSenateDistrict,

        category: form.contactCategory,
        supportLevel: form.supportLevel,
        bestContactMethod: form.bestContactMethod,

        teamAssignments: form.teamAssignments,
        rolePotential: form.rolePotential,
        tags: form.tags,

        introducedBy: form.introducedBy,
        organization: form.affiliation,
        metWhere: form.metWhere,
        metWhereDetails: form.metWhereDetails,
        eventName: form.eventName,

        topIssue: form.topIssue,
        conversationNotes: form.conversationNotes,

        interestedVolunteer: form.interestedVolunteer,
        interestedDonate: form.interestedDonate,
        interestedHostEvent: form.interestedHostEvent,
        interestedYardSign: form.interestedYardSign,
        interestedCountyLeader: form.interestedCountyLeader,
        interestedPrecinctCaptain: form.interestedPrecinctCaptain,

        influenceScore: form.influenceScore,
        fundraisingPotential: form.fundraisingPotential,
        volunteerPotential: form.volunteerPotential,

        permissionToContact: form.permissionToContact,

        facebookConnected: form.facebookConnected,
        facebookProfileName: form.facebookProfileName,
        facebookHandle: form.facebookHandle,
        facebookUrl: form.facebookUrl,

        instagramHandle: form.instagramHandle,
        twitterHandle: form.twitterHandle,
        linkedinUrl: form.linkedinUrl,
        tiktokHandle: form.tiktokHandle,

        createdFrom: "LIVE_FIELD",
      });

      // 2) Origin log (for audit + future routing)
      await addOrigin({
        contactId: contact.id,
        originType: "LIVE_FIELD",
        originRef: "live-contact",
        notes: "Field intake via Live Contact Entry page",
        rawPayload: buildFollowupPayload(form),
      });

      // 3) Optional media (store locally; sync later)
      if (photo?.dataUrl) {
        await addContactMedia({
          contactId: contact.id,
          type: "PROFILE_PHOTO",
          dataUrl: photo.dataUrl,
          thumbnailDataUrl: photo.thumbnailDataUrl,
        });
      }

      // 4) LiveFollowUp is the canonical local field record (never disappears)
      await addLiveFollowUp({
        contactId: contact.id,

        followUpStatus: form.followUpStatus,
        followUpNotes: form.followUpNotes,
        followUpTargetAt: form.followUpTargetAt,
        followUpCompletedAt: null,

        archived: false,

        // Snapshot fields for list display + ops triage
        name: form.fullName,
        phone: form.phone,
        email: form.email,
        location: [form.city, form.county].filter(Boolean).join(", "),
        notes: form.conversationNotes,

        source: "LIVE_FIELD",
        automationEligible: form.automationEligible,
        permissionToContact: form.permissionToContact,

        facebookConnected: form.facebookConnected,
        facebookProfileName: form.facebookProfileName,
        facebookHandle: form.facebookHandle,
        facebookUrl: form.facebookUrl,

        instagramHandle: form.instagramHandle,
        twitterHandle: form.twitterHandle,
        linkedinUrl: form.linkedinUrl,
        tiktokHandle: form.tiktokHandle,

        entryInitials: form.entryInitials,

        contactCategory: form.contactCategory,
        supportLevel: form.supportLevel,
        bestContactMethod: form.bestContactMethod,

        teamAssignments: form.teamAssignments,
        rolePotential: form.rolePotential,
        tags: form.tags,

        metWhere: form.metWhere,
        metWhereDetails: form.metWhereDetails,
        introducedBy: form.introducedBy,
        affiliation: form.affiliation,
        eventName: form.eventName,

        topIssue: form.topIssue,
        conversationNotes: form.conversationNotes,

        precinct: form.precinct,
        congressionalDistrict: form.congressionalDistrict,
        stateHouseDistrict: form.stateHouseDistrict,
        stateSenateDistrict: form.stateSenateDistrict,

        interestedVolunteer: form.interestedVolunteer,
        interestedDonate: form.interestedDonate,
        interestedHostEvent: form.interestedHostEvent,
        interestedYardSign: form.interestedYardSign,
        interestedCountyLeader: form.interestedCountyLeader,
        interestedPrecinctCaptain: form.interestedPrecinctCaptain,

        influenceScore: form.influenceScore,
        fundraisingPotential: form.fundraisingPotential,
        volunteerPotential: form.volunteerPotential,
      });

      // 5) Best-effort sync (don’t block the canvasser if it fails)
      try {
        await syncPendingFollowUps();
      } catch {
        // ignored on purpose; offline-first
      }

      setJustSaved(true);

      // SPEED UX: reset + keep initials
      const keepInitials = form.entryInitials;
      const keepPermission = form.permissionToContact;
      reset();
      update("entryInitials", keepInitials as LiveContactForm["entryInitials"]);
      update(
        "permissionToContact",
        keepPermission as LiveContactForm["permissionToContact"]
      );

      clearPhoto();
    } catch (err: any) {
      setSubmitError(err?.message ?? "Failed to save. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  async function retrySync() {
    setSubmitError(null);
    try {
      await syncPendingFollowUps();
    } catch (e: any) {
      setSubmitError(e?.message ?? "Sync failed. You may be offline.");
    }
  }

  return (
    <Container>
      <Card>
        <CardHeader
          title="Live Contact Entry"
          subtitle="Offline-first. Auto-sync enabled."
        />

        <CardContent className="space-y-6">
          {submitError ? (
            <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-800">
              {submitError}
            </div>
          ) : null}

          {justSaved ? (
            <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-900">
              Saved locally ✅
            </div>
          ) : null}

          <form onSubmit={onSubmit} className="space-y-6">
            <ContactIdentitySection form={form} update={update} />
            <ContactLocationSection form={form} update={update} />
            <MeetingContextSection form={form} update={update} />

            <CampaignCategorySection form={form} update={update} />
            <TeamAssignmentSection form={form} update={update} />
            <EngagementSignalsSection form={form} update={update} />

            <SocialProfilesSection form={form} update={update} />
            <ConversationNotesSection form={form} update={update} />
            <FollowUpSection form={form} update={update} />

            <PhotoCaptureSection photo={photo} setPhoto={setPhoto} />

            <div className="flex flex-wrap items-center justify-end gap-3 pt-2">
              <Button type="button" variant="secondary" onClick={retrySync}>
                Retry Sync
              </Button>

              <Button type="submit" disabled={!readyToSave || submitting}>
                {submitting ? "Saving…" : "Save & Add Next"}
              </Button>

              <Button
                type="button"
                variant="secondary"
                onClick={() => nav("/live-contacts")}
              >
                Go to Follow-Ups
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </Container>
  );
}